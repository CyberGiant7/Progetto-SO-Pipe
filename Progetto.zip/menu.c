#include "menu.h"

char *gioca[3]={"┏━┓┳┏━┓┏━┓┏━┓",
                "┃ ┳┃┃ ┃┃  ┣━┫",
                "┗━┛┻┗━┛┗━┛┻ ┻"};

char *esci[9]={"┏━┓┏━┓┏━┓┳",
               "┣━ ┗━┓┃  ┃",
               "┗━┛┗━┛┗━┛┻"};

char *opzioni_stampa[9]={"┏━┓┏━┓━━┓┳┏━┓┳ ┳ ┳",
                         "┃ ┃┣━┛┏━┛┃┃ ┃┃╲┃ ┃",
                         "┗━┛┻  ┗━━┻┗━┛┻ ┻ ┻"};

char *titolo[DIM_TITOLO]={"          ___________  ___  _____  _____                 ",
                          "         /  ___| ___ \\/ _ \\/  __ \\|  ___|             ",
                          "         \\ `--.| |_/ / /_\\ \\ /  \\/| |__              ",
                          "          `--. \\  __/|  _  | |    |  __|                ",
                          "         /\\__/ / |   | | | | \\__/\\| |___              ",
                          "         \\____/\\_|   \\_| |_/\\____/\\____/            ",
                          "                                                         ",
                          "______ ___________ _____ _   _______ ___________         ",
                          "|  _  \\  ___|  ___|  ___| \\ | |  _  \\  ___| ___ \\    ",
                          "| | | | |__ | |_  | |__ |  \\| | | | | |__ | |_/ /       ",
                          "| | | |  __||  _| |  __|| . ` | | | |  __||    /         ",
                          "| |/ /| |___| |   | |___| |\\  | |/ /| |___| |\\ \\      ",
                          "|___/ \\____/\\_|   \\____/\\_| \\_/___/ \\____/\\_| \\_|",
                          "                                                         "};

StatoCorrente area_menu();

int maxx = DEFAULT_MAXX; /* Numero di colonne dello schermo */
int maxy = DEFAULT_MAXY; /* Numero di righe dello schermo */

StatoCorrente menu() {
    char parametro[25];
    setlocale(LC_ALL, "");

    StatoCorrente status;

    initscr(); /* inizializzazione dello schermo */
    noecho(); /* i caratteri corrispondenti ai tasti premuti non saranno visualizzati sullo schermo del terminale */
    curs_set(0);

    sprintf(parametro, "printf '\033[8;%d;%dt'", maxy, maxx);
    system(parametro);
    resize_term(maxy, maxx);


    start_color();
    init_pair(0, COLOR_BLACK, COLOR_BLACK); //per cancellare
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
    init_pair(2, COLOR_BLACK, COLOR_WHITE);
    init_pair(3, COLOR_BLUE, COLOR_BLACK);
    refresh();

    status = area_menu();
    return status;
}


StatoCorrente area_menu() {
    int i;
    prctl(PR_SET_NAME, (unsigned long) "Menu");

    for (i = 0; i < DIM_TITOLO; ++i) {
        attron(COLOR_PAIR(1));
        mvprintw(i, (maxx - 48) / 2, "%s\n", titolo[i]);
        attroff(COLOR_PAIR(1));
    }


    WINDOW *menuwin = newwin(12, maxx - 30, 14, 30 / 2);
    box(menuwin, 0, 0);
    refresh();
    wrefresh(menuwin);

    keypad(menuwin, TRUE);
    char *scelte[MENU_ELEM] = {"GIOCA",
                               "OPZIONI",
                               "ESCI"};
    int scelta;
    int selezione = 0;

    while (TRUE) {
        wmove(menuwin, 0, 1);
        for (i = 0; i < MENU_ELEM; ++i) {
            if (i == selezione)
                wattron(menuwin, A_REVERSE);
            switch (i) {
                case 0:
                    for (int j = 0; j < 3; ++j) {
                        mvwprintw(menuwin, 1+j, 20, gioca[j]);
                    }
                    break;
                case 1:
                    for (int j = 0; j < 3; ++j) {
                        mvwprintw(menuwin, 4+j, 20, opzioni_stampa[j]);
                    }
                    break;
                case 2:
                    for (int j = 0; j < 3; ++j) {
                        mvwprintw(menuwin, 7+j, 20, esci[j]);
                    }
                    break;

            }
            wattroff(menuwin, A_REVERSE);
        }
        refresh();
        wrefresh(menuwin);
        scelta = wgetch(menuwin);
        switch (scelta) {
            case KEY_UP:
                selezione--;
                if (selezione == -1)
                    selezione = 0;
                break;
            case KEY_DOWN:
                selezione++;
                if (selezione == MENU_ELEM)
                    selezione = MENU_ELEM - 1;
                break;
            default:
                break;
        }
        if (scelta == 10) //caso enter
            break;
    }
    switch (selezione) {
        case 0: //caso Gioca
            return GIOCA;
            break;
        case 1: // caso Opzioni
            return OPZIONI;
            break;
        case 2: //caso Esci
            return ESCI;
            break;
    }
}

#define NUMERO_OPZIONI 3
#define NUMERO_RISOLUZIONI 5
StatoCorrente opzioni(){
    clear();
    WINDOW *menuwin = newwin(6, maxx -12, 1, 12/2);
    box(menuwin, 0, 0);
    refresh();
    wrefresh(menuwin);

    keypad(menuwin, TRUE);
    char *scelte[NUMERO_OPZIONI] ={"\u2B05 Indietro",
                                   "Nemici",
                                   "Risoluzione"};
    char *risoluzioni[NUMERO_RISOLUZIONI]={"80  x 24",
                                           "100 x 30",
                                           "100 x 45",
                                           "150 x 45",
                                           "170 x 51"};
    int scelta;
    int selezione = 0;

    while(TRUE){
        wmove(menuwin,0,1);
        for (int i = 0; i < NUMERO_OPZIONI; ++i) {
            if (i == selezione)
                wattron(menuwin, A_REVERSE);
            wprintw(menuwin, "%s──",scelte[i]);
            wattroff(menuwin, A_REVERSE);
        }
        scelta = wgetch(menuwin);
        switch (scelta) {
            case KEY_LEFT:
                selezione--;
                if(selezione == -1)
                    selezione = 0;
                break;
            case KEY_RIGHT:
                selezione++;
                if (selezione == NUMERO_OPZIONI)
                    selezione= NUMERO_OPZIONI -1;
                break;
            default:
                break;
        }
        switch (selezione) {
            case 0:
                break;
            case 1:
                mvwprintw(menuwin, 1, 1, "Inserire Numero dei nemici:");
                break;
            case 2:
                for (int i = 0; i < NUMERO_RISOLUZIONI; ++i) {
                    mvwprintw(menuwin, 1+i, 1, risoluzioni[i]);
                }
                break;
        }
        if (scelta == 10) //caso enter
            break;
    }


//    sleep(5);
    return MENU;
}