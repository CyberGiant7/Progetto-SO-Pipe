#define _POSIX_SOURCE
#define _DEFAULT_SOURCE
#ifndef PROGETTO_SO__PIPE_MENU_H
#define PROGETTO_SO__PIPE_MENU_H

#include <stdio.h>
#include <curses.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <locale.h>
#include <fcntl.h>
#include <sys/prctl.h> // momentanea, per dare nomi ai processi


#define MENU_ELEM 3
#define DEFAULT_MAXX 100
#define DEFAULT_MAXY 30
#define DIM_TITOLO 14

typedef enum {GIOCA, MENU, OPZIONI, ESCI} StatoCorrente;



StatoCorrente menu();
extern StatoCorrente gioco();
StatoCorrente opzioni();

#endif //PROGETTO_SO__PIPE_MENU_H
