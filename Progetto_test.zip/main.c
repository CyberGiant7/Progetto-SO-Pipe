#include "menu.h"

#define KEY_SPACE 32
#define DIM_NAVICELLA 6
#define DIM_NEMICO 3
#define maxx 80 /* Numero di colonne dello schermo */
#define maxy 24 /* Numero di righe dello schermo */
#define NAVE 0  // identificatore posizione navicella
#define MISSILE_1 1 // identificatore posizione Missile 1
#define MISSILE_2 2 // identificatore posizione Missile 2
#define MAX_MISSILI 10 // Numero massimo di missili sparabili contemporaneamente

// DA 200 a 300  identificatori per i missili
// DA 11 a 100   identificatori Nemici
// Da 101 a 150  identinficatori Bombe nemiche

/* Struttura per la comunicazione tra figli e padre */
typedef struct {
    int n; /* soggetto che invia il dato: vespa o nave_player */
    int x; /* coordinata x */
    int y; /* coordinata y */
    _Bool in_vita;
} Pos;

_Noreturn void nave_player(int pipeout);
void AreaGioco(int pipein);

int M; //Numero nemici
int num_missili = 0;

char *nave[DIM_NAVICELLA]= {" ▟█▛▀▀",
                            "▟██▙  ",
                            "▗▟█▒▙▖",
                            "▝▜█▒▛▘",
                            "▜██▛  ",
                            " ▜█▙▄▄"
};

char *nemico_lv1[DIM_NEMICO]={"▀█▙",
                              "▒█ ",
                              "▄█▛"
};

char *nemico_lv2[DIM_NEMICO]={" △ "
                              "◁ ◊"
                              " ▽ "
};
/*
▀
▄
▗
▖
▘
▝
▙
▚
▛
▜
▞
▟
█
  	◀
*/


int main() {
    StatoCorrente status;
    status = MENU;
    M = 20;

    while (TRUE) {
        switch (status) {
            case GIOCA:
                status = gioco();
                break;
            case MENU:
                status = menu();
                break;
            case ESCI:
                return 0;
        }
        clear();
        refresh();
    }
}

StatoCorrente gioco() {
    int filedes[2];
    int pid_navicella;
    int i;
    pid_t pid_nemici = 1;
    Pos *array_pos_nemici = NULL;
    signal(SIGCHLD, SIG_IGN);

    setlocale(LC_ALL, "");
    initscr(); /* inizializzazione dello schermo */
    noecho(); /* i caratteri corrispondenti ai tasti premuti non saranno visualizzati sullo schermo del terminale */
    srand(time(NULL)); /* inizializziamo il generatore di numeri random */
    curs_set(0); /* nasconde il cursore */

    start_color();
    init_pair(0, COLOR_BLACK, COLOR_BLACK); // per cancellare
    init_pair(1, COLOR_WHITE, COLOR_BLACK); // per scrivere

    bkgd(COLOR_PAIR(1));

    if (pipe(filedes) == -1) { //inizializzazione della pipe con AreaGioco degli errori
        perror("Errore nella creazione della pipe!");
        _exit(1);
    }

    pid_navicella = fork(); //generazione di un secondo processo figlio per la nave_player
    switch (pid_navicella) {
        case -1:
            perror("Errore nell'esecuzione della fork.");
            _exit(1);
        case 0:
            prctl(PR_SET_NAME, (unsigned long) "Navicella");
            mvprintw(maxy / 2, maxx / 2, "%s", nave);
            close(filedes[0]); /* chiusura del descrittore di lettura (standard input)*/
            nave_player(
                    filedes[1]); /* il secondo processo figlio invoca la funzione nave_player passandogli la pipe in scrittura*/
        default:    //processo padre
            array_pos_nemici = (Pos *) malloc(sizeof(Pos) * M);
            int temp;
            for (i = 0; i < M; i++) {
                pid_nemici = fork();
                if (pid_nemici == -1) {
                    perror("Errore nell'esecuzione della fork.");
                    _exit(1);
                } else if (pid_nemici == 0) {
                    while (true) {
                        char nome[10];
                        sprintf(nome, "Nemico_%d", i);
                        prctl(PR_SET_NAME, (unsigned long) nome);
                        array_pos_nemici[i].y = 1 + (i % 5) * (DIM_NEMICO + 1);
                        temp = (int) (i / 5) + 1;
                        array_pos_nemici[i].x = maxx - temp * (DIM_NEMICO + 1);
                        array_pos_nemici[i].n = 11 + i;
                        write(filedes[1], &array_pos_nemici[i], sizeof(array_pos_nemici[i]));
                        usleep(1000000);
                    }
                } else if (pid_nemici != 0) {
                    continue;
                }
            }
            prctl(PR_SET_NAME, (unsigned long) "Area_gioco");
            close(filedes[1]); /* chiusura del descrittore di scrittura (standard output)*/
            AreaGioco(filedes[0]); /* il processo padre invoca la funzione di AreaGioco */

    }
    /* siamo usciti dalla funzione di AreaGioco e vengono terminati i 2 processi figli e ripristinato il normale modo operativo dello schermo */
    kill(pid_navicella, 1);
    clear();
    attron(COLOR_PAIR(1));
    printw("   _____              __  __   ______    ____   __      __  ______   _____    \n"
           "  / ____|     /\\     |  \\/  | |  ____|  / __ \\  \\ \\    / / |  ____| |  __ \\   \n"
           " | |  __     /  \\    | \\  / | | |__    | |  | |  \\ \\  / /  | |__    | |__) |  \n"
           " | | |_ |   / /\\ \\   | |\\/| | |  __|   | |  | |   \\ \\/ /   |  __|   |  _  /   \n"
           " | |__| |  / ____ \\  | |  | | | |____  | |__| |    \\  /    | |____  | | \\ \\   \n"
           "  \\_____| /_/    \\_\\ |_|  |_| |______|  \\____/      \\/     |______| |_|  \\_\\");
    refresh();
    sleep(500);
    endwin();
    free(array_pos_nemici);
    return MENU;
}



void nave_player(int pipeout) {
    int filedes[2];
    int pid_missile1;
    int pid_missile2;
    Pos pos_missile1, pos_missile2, temp_missile;
    Pos pos_navicella;
    _Bool morto;

    pos_navicella.n = NAVE;
    pos_navicella.x = 1;
    pos_navicella.y = maxy / 2;

    if (pipe(filedes) == -1) { //inizializzazione della pipe con AreaGioco degli errori
        perror("Errore nella creazione della pipe!");
        _exit(1);
    }
    if (fcntl(filedes[0], F_SETFL, O_NONBLOCK) < 0) //pipe non bloccante
        exit(2);

    write(pipeout, &pos_navicella, sizeof(pos_navicella));

    signal(SIGCHLD, SIG_IGN);

    keypad(stdscr, TRUE);
    while (1) {
        morto = FALSE;
        nodelay(stdscr, 1);
        timeout(500);
        int c = getch();
        switch (c) {
            case KEY_UP:
                if (pos_navicella.y > 1)
                    pos_navicella.y -= 1;
                write(pipeout, &pos_navicella, sizeof(pos_navicella));
                break;
            case KEY_DOWN:
                if (pos_navicella.y < maxy - DIM_NAVICELLA)
                    pos_navicella.y += 1;
                write(pipeout, &pos_navicella, sizeof(pos_navicella));
                break;
            case KEY_SPACE:
                if (num_missili <= MAX_MISSILI-2) {
                    num_missili += 2;
                    int status;
                    pos_missile1.y = pos_navicella.y + (DIM_NAVICELLA / 2);
                    pos_missile1.x = pos_navicella.x + DIM_NAVICELLA;
                    pos_missile2.y = pos_navicella.y + (DIM_NAVICELLA / 2);
                    pos_missile2.x = pos_navicella.x + DIM_NAVICELLA;

                    pos_missile1.n = 200 + num_missili -2;
                    pos_missile2.n = 201 + num_missili -2;

                    int i = 0;

                    pid_missile1 = fork(); //generazione processo
                    switch (pid_missile1) {
                        case -1:
                            perror("Errore nell'esecuzione della fork.");
                            exit(1);
                        case 0:
                            prctl(PR_SET_NAME, (unsigned long) "Missile 1");
                            /* funzione che genera coordinate missile 1*/
                            i = 0;
                            while (TRUE) {
                                if (i % 7 == 0) {
                                    pos_missile1.y -= 1;
                                }
                                pos_missile1.x += 1;
                                write(pipeout, &pos_missile1, sizeof(pos_missile1));
                                i++;
                                if (pos_missile1.x > maxx || pos_missile1.y <= 0) {
                                    morto = true;
                                    write(filedes[1], &morto, sizeof(morto));
                                    exit(1);
                                }
                                usleep(100000);
                            }
                            break;
                        default: //processo padre
                            pid_missile2 = fork(); //generazione di un secondo processo figlio per la nave_player
                            switch (pid_missile2) {
                                case -1:
                                    perror("Errore nell'esecuzione della fork.");
                                    exit(1);
                                case 0:
                                    prctl(PR_SET_NAME, (unsigned long) "Missile 2");
                                    i = 0;
                                    while (TRUE) {
                                        if (i % 7 == 0) {
                                            pos_missile2.y += 1;
                                        }
                                        pos_missile2.x += 1;
                                        write(pipeout, &pos_missile2, sizeof(pos_missile2));
                                        i++;
                                        if (pos_missile2.x > maxx || pos_missile2.y >= maxy) {
                                            morto = true;
                                            write(filedes[1], &morto, sizeof(morto));
                                            exit(1);
                                        }
                                        usleep(100000);
                                    }
                                    break;
                                default:
                                    break;
                            }
                    }
                    break;
                }
        }
        read(filedes[0], &morto, sizeof(morto));
        if (morto) {
            num_missili--;
        }
    }
}


void AreaGioco(int pipein) {
    refresh();
    int vite = 1000;
    int i, j;
    _Bool collision = false;
    Pos navicella, valore_letto;
    Pos missili[MAX_MISSILI];
    navicella.x = -1;

    while (true) {
        move(0, 1);
        clrtoeol();
        printw("VITE: %d", vite);
        refresh();
        read(pipein, &valore_letto, sizeof(valore_letto)); /* leggo dalla pipe */
        if (valore_letto.n == NAVE) {
            if (navicella.x >= 0) { /* cancello la 'vecchia' posizione della navicella */
                attron(COLOR_PAIR(0));
                for (i = 0; i < DIM_NAVICELLA; i++) {
                    mvprintw(navicella.y + i, navicella.x, "      ");
                }
                attron(COLOR_PAIR(1));
                for (i = 0; i < DIM_NAVICELLA; i++) {
                    mvprintw(valore_letto.y + i, valore_letto.x, nave[i]);
                }
            }
            navicella = valore_letto;
        } else if (valore_letto.n >= 200 && valore_letto.n <= 300) {
                attron(COLOR_PAIR(0));
                mvprintw(missili[valore_letto.n - 200].y, missili[valore_letto.n - 200].x, " ");
                attron(COLOR_PAIR(1));
                mvprintw(valore_letto.y, valore_letto.x, "卐"); ///♿ ⟢ ⁂ ꗇ ꗈ 💣 🚀
                missili[valore_letto.n - 200] = valore_letto;
        }
        /*if (valore_letto.n == 11){
            for (j = 0; j < DIM_NEMICO; j++) {
                mvprintw(valore_letto.y, valore_letto.x, nemico_lv1[j]);
            }
        }*/

        for(i=0; i < M; i++) {
            if (valore_letto.n >= 11 && valore_letto.n <= 11 + M) {
                attron(COLOR_PAIR(1));
                for (j = 0; j < DIM_NEMICO; j++) {
                    mvprintw(valore_letto.y+j, valore_letto.x, nemico_lv1[j]);
                }
            }
        }
        /* visualizzo l'oggetto nella posizione aggiornata */
        //if (vespa.x == navicella.x + DIM_NAVICELLA - 1 && vespa.y == navicella.y + i)
        /*for (i = 0; i < DIM_NAVICELLA; i++) {
            if ((vespa.x == navicella.x + i && vespa.y == navicella.y)
                || (vespa.x == navicella.x + i && vespa.y == navicella.y + DIM_NAVICELLA - 1)
                || ) {
                vite -= 3;
                if (navicella.x < maxx) navicella.x += 1; else navicella.x -= 1;
                if (navicella.y < maxy) navicella.y += 1; else navicella.y -= 1;
            }
            if (valore_letto.c == '#' && valore_letto.y != 0 || valore_letto.x != 1) {

            }*/

        curs_set(0);
        refresh();
        if (vite == 0)
            collision = true;
    }
}